import React, { useEffect, useState } from 'react';
import Papa from 'papaparse';
import FlightMap from './components/FlightMap';
import { Flight, FlightData, FlightState, CurrentFlightStatus } from './types';
import { Plane, Compass, Gauge, Mountain, MapPin, AlertCircle } from 'lucide-react';

// Helper function to convert DMS to decimal degrees
function parseDMS(dms: string): number {
  if (!dms) return 0;
  
  // Handle formats like "N40:46:13" or "W73:51:46"
  const direction = dms.charAt(0);
  const parts = dms.substring(1).split(':').map(Number);
  
  if (parts.length !== 3) return 0;
  
  let decimal = parts[0] + parts[1] / 60 + parts[2] / 3600;
  
  // Make negative for West or South
  if (direction === 'W' || direction === 'S') {
    decimal = -decimal;
  }
  
  return decimal;
}

function App() {
  const [flights, setFlights] = useState<Flight[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStatus, setCurrentStatus] = useState<CurrentFlightStatus | null>(null);

  const loadCSVFile = async (path: string) => {
    try {
      const response = await fetch(path);
      const text = await response.text();
      return new Promise<any[]>((resolve) => {
        Papa.parse(text, {
          header: true,
          complete: (results) => {
            resolve(results.data);
          },
        });
      });
    } catch (error) {
      console.error('Error loading CSV:', error);
      return [];
    }
  };

  useEffect(() => {
    const loadFlightData = async () => {
      // Load both flight data and states
      const [flightData, statesData] = await Promise.all([
        loadCSVFile('/data/US_1549'),
        loadCSVFile('/data/states')
      ]);

      if (flightData.length > 0) {
        // Process flight data
        const processedData = flightData
          .map((row: any, index: number) => ({
            timestamp: index,
            Latitude: parseDMS(row.Latitude as string),
            Longitude: parseDMS(row.Longitude as string),
            Altitude: parseFloat(row.Altitude as string),
            Speed: parseFloat(row.Speed as string),
            Heading: parseFloat(row.Heading as string)
          }))
          .filter(row => !isNaN(row.Speed) && !isNaN(row.Altitude) && !isNaN(row.Heading));

        // Process states data
        const processedStates = statesData
          .map((row: any) => ({
            timestamp: parseInt(row.timestamp),
            event: parseInt(row.event),
            issue: row.issue
          }))
          .filter(state => !isNaN(state.timestamp) && !isNaN(state.event));

        setFlights([{
          id: 1,
          data: processedData,
          states: processedStates,
          currentIndex: 0
        }]);

        // Set initial status
        setCurrentStatus({
          data: processedData[0],
          state: processedStates.find(s => s.timestamp === 0) || null
        });
      }
    };

    loadFlightData();
  }, []);

  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (isPlaying) {
      interval = setInterval(() => {
        setFlights((prevFlights) =>
          prevFlights.map((flight) => {
            const newIndex = (flight.currentIndex + 1) % flight.data.length;
            const newData = flight.data[newIndex];
            const newState = flight.states.find(s => s.timestamp === newIndex) || null;
            
            setCurrentStatus({
              data: newData,
              state: newState
            });

            return {
              ...flight,
              currentIndex: newIndex,
            };
          })
        );
      }, 20);
    }

    return () => {
      if (interval) {
        clearInterval(interval);
      }
    };
  }, [isPlaying]);

  const FlightInfo = ({ status }: { status: CurrentFlightStatus }) => (
    <div className="space-y-4 mb-6">
      <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
        <div className="grid grid-cols-4 gap-4 flex-1">
          <div className="flex items-center gap-2">
            <Compass className="h-5 w-5 text-blue-600" />
            <div>
              <div className="text-sm text-gray-600">Heading</div>
              <div className="font-semibold">{status.data.Heading.toFixed(1)}°</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Gauge className="h-5 w-5 text-blue-600" />
            <div>
              <div className="text-sm text-gray-600">Speed</div>
              <div className="font-semibold">{status.data.Speed.toFixed(1)} knots</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Mountain className="h-5 w-5 text-blue-600" />
            <div>
              <div className="text-sm text-gray-600">Altitude</div>
              <div className="font-semibold">{status.data.Altitude.toFixed(0)} ft</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-blue-600" />
            <div>
              <div className="text-sm text-gray-600">Position</div>
              <div className="font-semibold text-sm">
                {Math.abs(status.data.Latitude).toFixed(4)}°{status.data.Latitude >= 0 ? 'N' : 'S'}, {' '}
                {Math.abs(status.data.Longitude).toFixed(4)}°{status.data.Longitude >= 0 ? 'E' : 'W'}
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3 ml-4 pl-4 border-l">
          <div className="text-sm font-medium">Status:</div>
          <div className={`h-3 w-3 rounded-full ${status.state?.event === 1 ? 'bg-red-500' : 'bg-green-500'}`}></div>
        </div>
      </div>
      
      {status.state?.event === 1 && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <div className="flex items-center gap-2 text-red-700">
            <AlertCircle className="h-5 w-5" />
            <h3 className="font-semibold">Current Issue</h3>
          </div>
          <p className="mt-1 text-red-600">{status.state.issue}</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="container mx-auto p-4">
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Plane className="h-6 w-6" />
              US Airways Flight 1549
            </h1>
            <div className="flex gap-4">
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className={`px-4 py-2 rounded-full font-semibold ${
                  isPlaying
                    ? 'bg-red-500 text-white'
                    : 'bg-green-500 text-white'
                }`}
              >
                {isPlaying ? 'Pause' : 'Play'}
              </button>
            </div>
          </div>
          {currentStatus && <FlightInfo status={currentStatus} />}
          {flights.length > 0 ? (
            <FlightMap flights={flights} />
          ) : (
            <div className="text-center py-12 text-gray-500">
              Loading flight data...
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;