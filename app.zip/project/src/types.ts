export interface FlightData {
  Speed: number;
  Altitude: number;
  Heading: number;
  Latitude: number;
  Longitude: number;
  timestamp?: number;
}

export interface FlightState {
  timestamp: number;
  event: number;
  issue: string;
}

export interface Flight {
  id: number;
  data: FlightData[];
  currentIndex: number;
  states: FlightState[];
}

export interface CurrentFlightStatus {
  data: FlightData;
  state: FlightState | null;
}