import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Plane } from 'lucide-react';
import { Flight } from '../types';

// Fix for default marker icon in React-Leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface FlightMapProps {
  flights: Flight[];
}

const createPlaneIcon = (heading: number) => {
  return L.divIcon({
    html: `<div style="transform: rotate(${heading}deg)"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.8 19.2 16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/></svg></div>`,
    className: 'plane-icon',
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
};

const isValidLatLng = (lat: number, lng: number): boolean => {
  return !isNaN(lat) && !isNaN(lng) && 
         lat >= -90 && lat <= 90 && 
         lng >= -180 && lng <= 180;
};

export default function FlightMap({ flights }: FlightMapProps) {
  const [center, setCenter] = useState<[number, number]>([40.7, -74]); // Default to NYC area

  useEffect(() => {
    if (flights.length > 0 && flights[0].data.length > 0) {
      const firstFlight = flights[0].data[0];
      if (isValidLatLng(firstFlight.Latitude, firstFlight.Longitude)) {
        setCenter([firstFlight.Latitude, firstFlight.Longitude]);
      }
    }
  }, [flights]);

  return (
    <div className="h-[600px] w-full">
      <MapContainer
        center={center}
        zoom={13}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        {flights.map((flight) => {
          const currentData = flight.data[flight.currentIndex];
          if (!isValidLatLng(currentData.Latitude, currentData.Longitude)) {
            return null;
          }
          return (
            <Marker
              key={flight.id}
              position={[currentData.Latitude, currentData.Longitude]}
              icon={createPlaneIcon(currentData.Heading)}
            >
              <Popup>
                <div>
                  <h3 className="font-bold">Flight {flight.id}</h3>
                  <p>Speed: {currentData.Speed} knots</p>
                  <p>Altitude: {currentData.Altitude} ft</p>
                  <p>Heading: {currentData.Heading}°</p>
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>
    </div>
  );
}